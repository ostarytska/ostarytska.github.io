function Footer() {
    return (
      <footer>
        <div className="contact-info">
          <p>Телефон: +380 (99) 123-45-67</p>
          <p><a href="#">Instagram: instagram</a></p>
          <p><a href="#">Telegram: Telegram</a></p>
        </div>
      </footer>
    );
  }
  
  export default Footer;
  