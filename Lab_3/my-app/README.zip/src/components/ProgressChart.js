function ProgressChart({ total, completed }) {
    const percent = (value, max) => (max === 0 ? 0 : Math.round((value / max) * 100));
  
    return (
      <section className="progress-summary">
        <h2>Мій прогрес</h2>
        <p>Виконано тренувань: {completed.length} / {total.length}</p>
  
        <h3>Прогрес</h3>
  
        <p>Тренування:</p>
        <div className="progress-bar">
          <div className="progress" style={{ width: `${percent(completed.length, total.length)}%` }}>
            {percent(completed.length, total.length)}%
          </div>
        </div>
  
        <p>Час:</p>
        <div className="progress-bar">
          <div className="progress" style={{ width: `${percent(
            completed.reduce((s, w) => s + w.duration, 0),
            total.reduce((s, w) => s + w.duration, 0)
          )}%` }}>
            {percent(
              completed.reduce((s, w) => s + w.duration, 0),
              total.reduce((s, w) => s + w.duration, 0)
            )}%
          </div>
        </div>
  
        <p>Калорії:</p>
        <div className="progress-bar">
          <div className="progress" style={{ width: `${percent(
            completed.reduce((s, w) => s + w.calories, 0),
            total.reduce((s, w) => s + w.calories, 0)
          )}%` }}>
            {percent(
              completed.reduce((s, w) => s + w.calories, 0),
              total.reduce((s, w) => s + w.calories, 0)
            )}%
          </div>
        </div>
      </section>
    );
  }
  
  export default ProgressChart;
  