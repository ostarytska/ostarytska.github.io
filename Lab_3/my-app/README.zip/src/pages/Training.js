// src/pages/Training.js
import { useEffect, useState } from "react";
import Header from "../components/Header";
import Footer from "../components/Footer";
import WorkoutCard from "../components/WorkoutCard";

function Training() {
  const [workouts, setWorkouts] = useState([]);
  const [filter, setFilter] = useState("усі");
  const [saved, setSaved] = useState(
    () => JSON.parse(localStorage.getItem("workoutsProgress")) || []
  );

  useEffect(() => {
    fetch("/workouts.json")
      .then((res) => res.json())
      .then((data) => setWorkouts(data));
  }, []);

  const handleStart = (workout) => {
    if (saved.some((item) => item.id === workout.id)) return;
    const updated = [...saved, workout];
    localStorage.setItem("workoutsProgress", JSON.stringify(updated));
    setSaved(updated);
  };

  const filtered = workouts.filter(
    (w) => filter === "усі" || w.type === filter
  );

  return (
    <>
      <Header title="My Plan" />
      <main>
        <section className="training-cards">
          <h1>Тренування</h1>

          <label htmlFor="filter">Фільтр за типом тренування:</label>
          <select
            id="filter"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          >
            <option value="усі">Усі</option>
            <option value="кардіо">Кардіо</option>
            <option value="силові">Силові</option>
            <option value="йога">Йога</option>
            <option value="пілатес">Пілатес</option>
          </select>

          <div className="workouts">
            {filtered.length === 0 ? (
              <p>Немає тренувань для обраного типу.</p>
            ) : (
              filtered.map((w) => (
                <WorkoutCard
                  key={w.id}
                  workout={w}
                  isCompleted={saved.some((item) => item.id === w.id)}
                  onStart={handleStart}
                />
              ))
            )}
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}

export default Training;
