import { useState, useEffect } from "react";
import Header from "../components/Header";
import Footer from "../components/Footer";
import ProgressChart from "../components/ProgressChart";

function Progress() {
  const [total, setTotal] = useState([]);
  const [completed, setCompleted] = useState([]);

  useEffect(() => {
    // Завантаження всіх тренувань
    fetch("/workouts.json")
      .then((res) => res.json())
      .then((data) => setTotal(data))
      .catch((err) => console.error("Помилка при завантаженні всіх тренувань:", err));

    // Завантаження завершених тренувань
    const saved = JSON.parse(localStorage.getItem("workoutsProgress")) || [];
    setCompleted(saved);
  }, []);

  return (
    <>
      <Header title="Мій прогрес" />
      <main>
        <ProgressChart total={total} completed={completed} />
      </main>
      <Footer />
    </>
  );
}

export default Progress;
