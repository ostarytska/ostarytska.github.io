import React from 'react';
import { Link } from 'react-router-dom';

function Header({
  title,
  backgroundColor = '#bb8c94',
  navLinkColor = 'white',
  navLinkHoverColor = '#ffcccb'
}) {
  const headerStyle = {
    backgroundColor,
    color: 'white',
    textAlign: 'center',
    padding: '20px',
  };

  return (
    <header style={headerStyle}>
      <h1 className="my-plan">{title}</h1>
      <nav className="nav-links">
        <Link to="/" style={{ color: navLinkColor }} className="nav-link" data-hover={navLinkHoverColor}>Тренування</Link>
        <Link to="/progress" style={{ color: navLinkColor }} className="nav-link" data-hover={navLinkHoverColor}>Мій прогрес</Link>
        <Link to="/diet" style={{ color: navLinkColor }} className="nav-link" data-hover={navLinkHoverColor}>Раціон</Link>
        <Link to="/workout-journal" style={{ color: navLinkColor }} className="nav-link" data-hover={navLinkHoverColor}>Журнал тренувань</Link>
      </nav>
    </header>
  );
}

export default Header;
