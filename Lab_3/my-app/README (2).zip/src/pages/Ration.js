import React from 'react';
import Header from "../components/Header";
import Footer from "../components/Footer";
import RecipeCard from "../components/RecipeCard";
import '../styles/ration.css';
function Ration() {
  const recipes = [
    {
      title: "Салат з тунцем",
      calories: "300 калорій",
      image: "/image1.jpg",
      ingredients: [
        "1 банка тунця в олії",
        "2 варених яйця",
        "100 г вареної картоплі",
        "100 г моркви",
        "1 цибуля",
        "Оливкова олія для заправки",
        "Сіль та перець за смаком"
      ],
      instructions: [
        "Відкрити банку з тунцем та злити олію.",
        "Відварити яйця та нарізати їх кубиками.",
        "Варити картоплю та моркву, потім нарізати кубиками.",
        "Все змішати в одній великій мисці.",
        "Додати сіль, перець і оливкову олію за смаком."
      ]
    },
    {
      title: "Томати з моцарелою",
      calories: "200 ккал",
      image: "/imagen2.webp",
      ingredients: [
        "2 середніх помідори",
        "100 г моцарели",
        "Базилік за смаком",
        "Оливкова олія, бальзамічний оцет",
        "Сіль, перець"
      ],
      instructions: [
        "Наріж помідори та моцарелу.",
        "Розклади на тарілці, чергуючи помідори та моцарелу.",
        "Полий олією та оцтом, посоли та поперчи.",
        "Посип базиліком та подавай."
      ]
    },
    {
      title: "Курячий салат з авокадо",
      calories: "350 калорій",
      image: "/image3.jpg",
      ingredients: [
        "1 куряче філе",
        "1 стиглий авокадо",
        "100 г огірків",
        "1 помідор",
        "50 г червоної цибулі",
        "1 ст. л. грецького йогурту або оливкової олії",
        "Сіль, перець, лимонний сік"
      ],
      instructions: [
        "Нарізати курку та авокадо кубиками.",
        "Порізати овочі та цибулю.",
        "Змішати все у мисці, додати йогурт, спеції та сік.",
        "Перемішати й подавати."
      ]
    }
  ];

  return (
    <>
      <Header title="Раціон" backgroundColor="#c4a590" navLinckColor="#ffffff" navLinckHoverColor="0000000"/> 
      <main className="ration-page">
        {recipes.map((recipe, i) => (
          <RecipeCard key={i} {...recipe} />
        ))}
      </main>
      <Footer backgroundColor="#c4a590"/>
    </>
  );
}


export default Ration;
